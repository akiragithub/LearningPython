Current maintainer: Tim Baker (treectrl@users.sourceforge.net)
Website: http://tktreectrl.sourceforge.net/

An extra help document with examples and pictures is available from
the main website:
http://tktreectrl.sourceforge.net/Understanding%20TkTreeCtrl.html
